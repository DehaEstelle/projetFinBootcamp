

</div>
        
     <script src="/js/acceuil.js"></script>
    </body>
    <footer>
    <p> @copy;copyright2023 </p>
</footer>
</html>  
         