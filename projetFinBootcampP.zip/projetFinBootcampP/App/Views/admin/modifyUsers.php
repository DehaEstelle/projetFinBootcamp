<?php
require("../App/Controllers/RegisterController.php");
    $stmt = new RegisterController();
    $arr = $stmt->showUsers();
?>

<main>
    <form action="/RegisterController/updateUsers" method="POST">
        <div>
            <input type="hidden" name="user_id" id="id2">

            <label for="firstname">Firstname</label>
            <input type="text" name="firstname" id="firstname">
        </div>
        <div>
            <label for="lastname">Lastname</label>
            <input type="text" name="lastname" id="lastname">
        </div>
        <div>
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
        </div>
        <div>
            <label for="password">Password</label>
            <input type="password" name="password">
        </div>
        <div>
            <label for="pwd">Confirmation password</label>
            <input type="password" name="confirm_pwd">
        </div>
        <div>
            <label for="user_role">Rôle de l'utilisateur</label>
            <select name="user_role" id="role">
                <option value="" selected desable></option>
                <option value="0">Administrateur Service</option>
                <option value="1">Utilisateur Service</option>
            </select>
        </div>
        <div>
            <label for="service">Service de l'utilisateur</label>
            <select name="service">
                <option value="" selected desable></option>
                <?php
                    $controleur = new RegisterController();
                    $stmt = $controleur->selectServiceUser();
                    foreach ($stmt as $key => $value) {
                ?>
                <option value="<?php echo $stmt[$key]["service_id"];?>"> <?php echo $stmt[$key]["service_lib"];?> </option>
                <?php   
                    }                      
                ?>
            </select>   
        </div>
        <button type="submit" name="modifier">Modifier</button>
    </form>

    <script src="/js/user.js"></script>
</main>