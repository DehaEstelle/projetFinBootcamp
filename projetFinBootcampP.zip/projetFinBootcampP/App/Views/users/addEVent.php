<?php

require('../App/Views/inc/header.php');
require('../App/validators/EventValidator.php');

    $validator= new EventValidator();
   
    $errors=[];
    $data=[];
   

    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $data=$_POST;
        $errors= $validator->validates($_POST);
    
        
    }
?>
    

<div class="container">
    <h1>Ajouter un évènement</h1>
    <?php if (!empty($errors)):   ?>
        <div class="alert alert-danger">
            Merci de corriger vos erreurs
        </div>
    <?php endif ;   ?>
    <form action="" method="post" class="form">
        
    <div class="row">
        <div class="col-sm-6">
            <div class="form-groupe">
                <label for="name">Titre</label>
                <input type="text" class="form-control" required name="name" id="name"
                value="<?= isset($data['name'])? htmlentities($data['name']):'' ?>">
                <?php if (isset($errors['name'])):   ?>
                    <small style="color:red;"><?= $errors['name'];   ?></small>
                <?php endif ;   ?>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label for="date">Date</label>
                <input class="form-control" type="date" required name="date" id="date" value="<?= isset($data['date'])? htmlentities($data['date']):'' ?>">
                <?php if (isset($errors['date'])):   ?>
                    <small style="color:red;"><?= $errors['date'];   ?></small>
                <?php endif ;   ?>
            </div>
        </div>
    </div>
    <div class="row">
    <div class="col-sm-6">
            <div class="form-group">
                <label for="start">Demarrage</label>
                <input class="form-control" type="time" required name="start" id="start" placeholder="HH:MM"
                value="<?= isset($data['start'])? htmlentities($data['start']):'' ?>">
                <?php if (isset($errors['start'])):   ?>
                    <small style="color:red;"><?= $errors['start'];   ?></small>
                <?php endif ;   ?>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label for="end">Fin</label>
                <input class="form-control" type="time" required name="end" id="end" placeholder="HH:MM"
                value="<?= isset($data['end'])? htmlentities($data['end']):'' ?>">
                <?php if (isset($errors['end'])):   ?>
                    <small style="color:red;"><?= $errors['end'];   ?></small>
                <?php endif ;   ?>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" id="description" class="form-control">
            <?= isset($data['name'])? htmlentities($data['name']):'' ?></textarea>
    </div>
    <div class="form-group">
        <button class="btn btn-primary">Add</button>
    </div>
    </form>
</div>


<?php  require('../App/Views/inc/footer.php');  ?>  