<?php

class Retrieve {
    public function home() {
        require("../App/Views/users/login.php");
    }

    public function index() {
        require("../App/Views/users/usersPage.php");
    }

    public function addUsers() {
        require("../App/Views/admin/usersPage.php");
    }

    public function showAdmin() {
        require("../App/Views/admin/admin.php");
    }

    public function addService() {
        require("../App/Views/admin/servicePage.php");
    }

    public function addSalle() {
        require("../App/Views/admin/sallePage.php");
    }

    public function addPlanning() {
        require("../App/Views/users/planningPage.php");
    }

    public function addEvent() {
        require("../App/Views/users/addEvent.php");
    }

}